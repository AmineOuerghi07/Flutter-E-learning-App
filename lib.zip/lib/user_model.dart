

class User {
  String fullName;
  String email;
  bool animateur;
  String adress;
  String mdp;

  User({
    this.fullName = '',
    this.email = '',
    this.animateur = false,
    this.adress = '',
    this.mdp = ''
  });
}